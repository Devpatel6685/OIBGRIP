# Simple-ToDo-App

Simple ToDo App (using HTML 5 , CSS 3, Bootstrap 4.0 and JavaScript)

Preview: https://mohammed-raafat.github.io/Simple-ToDo-App/

This was an application on The Modern JavaScript Bootcamp (2019) from Udemy: https://www.udemy.com/modern-javascript/
